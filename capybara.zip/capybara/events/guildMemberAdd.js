const { Events } = require('discord.js');

module.exports = {
	name: Events.GuildMemberAdd,
	execute(member) {
		channel = member.guild.channels.cache.get("960831251126824983")
		channel.send(`${member} vient de rejoindre notre sanctuaire <:capy:960978642182242357>\nBienvenue dans le royaume des Capybaras !`)

		role = member.guild.roles.cache.get('960835894762426398')
		member.roles.add(role)
	},
};
