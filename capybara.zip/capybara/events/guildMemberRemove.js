const { Events } = require('discord.js');

module.exports = {
	name: Events.GuildMemberRemove,
	execute(member) {
		channel = member.guild.channels.cache.get("960831251126824983")
		channel.send(`**${member.tag}** vient de quitter notre sanctuaire <:capy_trigger:960979175508967494>\nCe n'était qu'un barbare de païen.`)
	},
};