const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('dick')
		.setDescription('Calculer la taille du penis de quelqu\'un')
    .addUserOption(option =>
		    option.setName('user')
			     .setDescription('La personne a qui la taille sera calculé.')
			     .setRequired(true)),
	async execute(interaction) {

    const user = interaction.options.getUser('user');
    const taille = Math.floor(Math.random() * 30) + 1;
    const texts = ["Euh bah rip twa","Tkt, c'est pas la taille qui compte","C'est la moyenne quoi","Mon daron a la même","Ouah elle est si grosse!","Le mec c'est un tripode!","C'est le reccord du monde!"]

    let z = 0
    if (taille < 5) {z=0}
    else if (taille < 11) {z=1}
    else if (taille < 16) {z=2}
    else if (taille < 20) {z=3}
    else if (taille < 26) {z=4}
    else if (taille < 30) {z=5}
    else {z=6}

    let dick = "8"
    for (let i = 0; i < taille; i++) {
        dick+="="
    }

    await interaction.reply({content: `La bite de ${user} fait \`${taille}cm\`\n${texts[z]}\n${dick}D`, ephemeral: false});
	},
};
