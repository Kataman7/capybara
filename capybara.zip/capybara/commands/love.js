const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('love')
		.setDescription('Calculer le pourcentage d\'amour entre deux personnes.')
    .addUserOption(option =>
		    option.setName('user1')
			     .setDescription('La première personne du couple.')
			     .setRequired(true))
    .addUserOption(option =>
		    option.setName('user2')
			     .setDescription('La deuxième personne du couple.')
			     .setRequired(true)),
	async execute(interaction) {

    const user1 = interaction.options.getUser('user1');
    const user2 = interaction.options.getUser('user2');
    let x = Math.floor(Math.random() * 100) + 1;

    //if (interaction.member.id === "247789608945844224") {x = 100}

    let heart = ""
    let sentence = ""
    if (x < 10) {
        heart = "🖤"
        sentence = "Vaut mieux pas les laisser seul dans la même pièce..."
    }
    else if (x < 20) {
        heart = "🖤"
        sentence = "J'crois qu'ils ne s'aiment pas beaucoup."
    }
    else if (x < 30) {
        heart = "💚"
        sentence = "Il va falloir apprendre à mieux se connaître !"
    }
    else if (x <= 40) {
        heart = "💚"
        sentence = "Deux camarades scolaires toujours là pour s'envoyer les devoirs."
    }
    else if (x <= 50) {
        heart = "💙"
        sentence = "Ce sont deux gigas bros!"
    }
    else if (x <= 60) {
        heart = "💙"
        sentence = "Une relation plus qu'ambiguë..."
    }
    else if (x <= 70) {
        heart = "🧡"
        sentence = "Une relation est envisageable ..."
    }
    else if (x <= 80) {
        heart = "🧡"
        sentence = "Trouvez vous un lit bande de sauvage !"
    }
    else if (x <= 90) {
        heart = "❤️"
        sentence = "*C'est le grand amour !"
    }
    else {
        heart = "❤️"
        sentence = "C'est le vrai coup de foudre !"
    }

    

    await interaction.reply({content: `${user1} et ${user2} s'aime à \`${x}%!\` ${heart}\n${sentence}`, ephemeral: false});
	},
};
