const { SlashCommandBuilder } = require('@discordjs/builders');


module.exports = {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('Répondre avec pong!'),
	async execute(interaction) {
		
		const sent = await interaction.reply({ content: '🏓 Pong!', fetchReply: true });
		interaction.editReply(`Ma latence est de \`${sent.createdTimestamp - interaction.createdTimestamp}\`ms.`);

	}
}
