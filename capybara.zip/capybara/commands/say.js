const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('say')
		.setDescription('Faire parler le bot.')
    .addChannelOption(option =>
        option.setName('destination')
           .setDescription('Le salon ou sera envoyé le message.')
           .setRequired(true))
    .addStringOption(option =>
		    option.setName('input')
			     .setDescription('Le contenue du message.')
			     .setRequired(true)),
	async execute(interaction) {

        const string = interaction.options.getString('input');
        const channel = interaction.options.getChannel('destination');

        if (!interaction.member.roles.cache.some(role => role.id == "960835691082817536")) return interaction.reply({content: 'Seul un saint prophète peut parler au nom du Capybara <:capy_trigger:960979175508967494>', ephemeral: true})
        
        if (channel.type != 0) return await interaction.reply({content: 'Le capybara ne peut pas envoyer de message dans ce salon <:capy_trigger:960979175508967494>', ephemeral: true})

        await channel.send(string);
        await interaction.reply({content: `<:check:961212351070212117> Le a été envoyé dans ${channel}.`, ephemeral: true});
	},
};