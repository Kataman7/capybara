const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('clear')
		.setDescription('Supprimer des messages.')
    .addIntegerOption(option =>
        option.setName('amount')
           .setDescription('Le nombre de message à supprimer.')
           .setRequired(true)),

	async execute(interaction) {

        if (!interaction.member.roles.cache.some(role => role.id == "960835691082817536")) return interaction.reply({content: 'Seul un saint prophète peut manier l\'art de la censure <:capy_trigger:960979175508967494>', ephemeral: true})

        const amount = interaction.options.getInteger('amount');

        if (amount > 0 == false ) return await interaction.reply({content: `Vous devez entrer un nombre suppérieur à 0 <:capy_trigger:960979175508967494>`, ephemeral: true});

        const messages = await interaction.channel.messages.fetch({
            limit: amount +1,
        });

        await interaction.channel.bulkDelete(amount, true).then(messages => {
            interaction.reply({content: `<:check:961212351070212117> \`${messages.size}\` ont été supprimé.`, ephemeral: true});
        });
	},
};
